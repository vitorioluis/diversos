#encode:utf-8
import json, mechanize,sqlite3
conn = sqlite3.connect("Projeto C-3PO.db")
cursor = conn.cursor()


jogadores = []
rodada=0
results=[]

def info(jogador):
    dic=scout(jogador)
    return {
        'id':int(jogador['id']),
        'status':jogador['status'].encode('utf-8'),
        'posicao':jogador['posicao']['nome'].encode('utf-8'),
        'nome':jogador['apelido'].encode('utf-8').replace("'"," "),
        'time':jogador['clube']["nome"].encode('utf-8').replace("'"," "),
        'pontos':float(jogador['pontos']),
        'chance_de_valorizar': "alta" if float(jogador['pontos'])<float(jogador['media']) else "baixa",
        'media':float(jogador['media']),
        'preco':float(jogador['preco']),
        'variacao':float(jogador['variacao']),
        'clube_casa':jogador["partida_clube_casa"]["nome"].encode('utf-8'),
        'clube_visitante':jogador["partida_clube_visitante"]["nome"].encode('utf-8'),
        'jogos':int(jogador['jogos']),
#DEFENDENDO
        'RB':dic['RB'] if 'RB' in dic else 0,
        'FC':dic['FC'] if 'FC' in dic else 0,
        'GC':dic['GC'] if 'GC' in dic else 0,
        'CA':dic['CA'] if 'CA' in dic else 0,
        'CV':dic['CV'] if 'CV' in dic else 0,
        'SG':dic['SG'] if 'SG' in dic else 0,
        'DD':dic['DD'] if 'DD' in dic else 0,
        'DP':dic['DP'] if 'DP' in dic else 0,
        'GS':dic['GS'] if 'GS' in dic else 0,
#ATACANDO
        'FS':dic['FS'] if 'FS' in dic else 0,
        'PE':dic['PE'] if 'PE' in dic else 0,
        'A':dic['A'] if 'A' in dic else 0,
        'FT':dic['FT'] if 'FT' in dic else 0,
        'FD':dic['FD'] if 'FD' in dic else 0,
        'FF':dic['FF'] if 'FF' in dic else 0,
        'G':dic['G'] if 'G' in dic else 0,
        'I':dic['I'] if 'I' in dic else 0,
        'PP':dic['PP'] if 'PP' in dic else 0
    }

def scout(jogador):
    scout={}
    if len(jogador["scout"]) > 0:
        for a in jogador["scout"]:
            scout[a["nome"].encode('utf-8')]=int(a["quantidade"])
    return scout

def banco(sql):
    cursor.execute(sql)
    conn.commit()

def GeraDados():
    # br serÃ¡ o objeto que simula o browser
    br = mechanize.Browser()

    # Abre a pagina de login Cartola atraves do mechanize
    br.open('https://loginfree.globo.com/login/438')

    #Na pÃ¡gina, selecionamos o primeiro form presente. 'nr=0' indica que estamos selecionando o form de Indice 0 dentre os encontrados.
    #Analisando a página, vemos que realmente sera um form.
    #Aps selecionarmos o form, preenchemos os campos com username e senha que permitam fazer o login.
    br.select_form(nr=0)
    br.form['login-passaporte'] = 'vitorioluis@globo.com'
    br.form['senha-passaporte'] = 'totustuus1'
    br.submit()


##    i=1
##    while i<=100:
##        try:
##            url="http://cartolafc.globo.com/mercado/filtrar.json?page="+str(i)
##            r = br.open(url)
##            j = json.loads(r.read())
##            jogadores.extend(j['atletas'])
##            rodada=int(j[u'rodada_id']
##            i+=1
##        except:
##            i+=1
##            print(url)


    url="https://api.cartolafc.globo.com/atletas/mercado"
    r = br.open(url)
    j = json.loads(r.read())
    jogadores.extend(j['atletas'])
    rodada=int(j[u'rodada_id'])

def SalvaBanco():
    #ordem decrescente de pontos
    results = sorted(map(info, jogadores), key=lambda k: -k['pontos'])
    banco('delete from Jogadores where rodada={0}'.format(rodada))
    for j in sorted(results):
        sql="INSERT INTO Jogadores(rodada,idCartola,status,nome,time,pontos,chanceValorizar,media,posicao,preco,variacao,casa,visitante,numJogos,roubadaBola,faltaCometida,golContra,cartaoAmarelo,cartaoVermelho,JogosSemSofrerGols,defesaDificil,defesaPenalt,golSofrido,faltaSofrida,passeErrado,assistencia,finalizacaoTrave,finalizacaoDefendida,finalizacaoFora,gol,impedimento,penaltiPerdido) VALUES({0},'{id}','{status}','{nome}','{time}','{pontos}','{chance_de_valorizar}','{media}','{posicao}','{preco}','{variacao}','{clube_casa}','{clube_visitante}','{jogos}','{RB}','{FC}','{GC}','{CA}','{CV}','{SG}','{DD}','{DP}','{GS}','{FS}','{PE}','{A}','{FT}','{FD}','{FF}','{G}','{I}','{PP}')".format(rodada,**j)
        try:
            banco(sql)
        except:
            print(sql)


def GeraTxt():
    cartola=open('DadosTxt/'+str(rodada)+'-Cartola.txt','w')
    titulo="rodada|idCartola|status|nome|time|pontos|chanceValorizar|media|posicao|preco|variacao|casa|visitante|numJogos\n"
    cartola.write(titulo)

    for j in sorted(results):
        s="{0}|{id}|{status}|{nome}|{time}|{pontos}|{chance_de_valorizar}|{media}|{posicao}|{preco}|{variacao}|{clube_casa}|{clube_visitante}|{jogos}\n".format(rodada,**j)
        cartola.write(s)
    cartola.close()

if __name__=='__main__':
    GeraDados()
    SalvaBanco()
    # GeraTxt()


#recebe um jogador e retorna um dicionÃ¡rio com apenas as informaÃ§Ãµes que queremos, podendo calcular informaÃ§Ãµes interessantes.
##SCOUTS DE DEFESA
##J	Jogos	0 pts
##RB	Roubada de Bola	+1,7 pts
##FC	Falta cometida	-0,5 pts
##GC	Gol Contra	-6,0 pts
##CA	CartÃ£o amarelo	-2,0 pts
##CV	CartÃ£o Vermelho	-5,0 pts
##SG	Jogos sem sofrer gols	+5,0 pts
##DD	Defesa DifÃ­cil  legenda	+3,0 pts
##DP	Defesa de pÃªnalti  legenda	+7,0 pts
##GS	Gol Sofrido  legenda	-2,0 pts
##
##SCOUTS DE ATAQUE
##J	Jogos	0 pts
##FS	Falta sofrida	+0,5 pts
##PE	Passe errado	-0,3 pts
##A	AssistÃªncia	5,0 pts
##FT	FinalizaÃ§Ã£o na trave	3,5 pts
##FD	FinalizaÃ§Ã£o defendida	1,0 pts
##FF	FinalizaÃ§Ã£o fora	0,7 pts
##G	Gol	+8,0 pts
##I	Impedimento	-0,5 pts
##PP	PÃªnalti perdido	-3,5 pts
